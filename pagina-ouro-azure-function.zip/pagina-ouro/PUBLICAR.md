# Publicar a página de ouro: Azure Function

Tarefa mecânica. NÃO escreva nem reescreva conteúdo: publique os arquivos desta pasta como estão.
Terminal: Git Bash. Página: "Azure Function", ID 3518078392.

Arquivos:
- `azure-function.storage.xml`: corpo da página em formato de armazenamento (9 macros).
- `function-fluxo-sincronizacao.drawio`: diagrama do fluxo (XML do draw.io).
- `function-fluxo-sincronizacao.png`: prévia (pode ser substituída pela exportação local, passo 3).

Pare e me reporte se qualquer passo falhar. Não improvise.

1. Copie esta pasta para `~/doc-rascunhos/molicar/azure-function/` e trabalhe lá.

2. Backup: `confluence_get_page` com `page_id: 3518078392`, `convert_to_markdown: false`, `include_metadata: true`. Salve o corpo exatamente como veio em `azure-function.original.xml` e anote a versão atual da página.

3. Links: confirme com `confluence_search` que existem no espaço páginas com estes títulos exatos. Se algum não existir, pare e me diga o título real mais próximo.
   - `Molicar`
   - `Fluxo E2E — Parceiro → ADF → PostgreSQL → Backend`

4. Diagrama (skill `confluence-bradesco`, references/drawio.md):
   - Exporte a prévia: `"/c/Program Files/draw.io/draw.io.exe" -x -f png -e -b 10 -o function-fluxo-sincronizacao.png function-fluxo-sincronizacao.drawio`
   - Meça: `python -c "import struct,sys;d=open(sys.argv[1],'rb').read(24);print(*struct.unpack('>II',d[16:24]))" function-fluxo-sincronizacao.png`
   - `cp function-fluxo-sincronizacao.drawio function-fluxo-sincronizacao`
   - `confluence_upload_attachment` na página 3518078392: primeiro `function-fluxo-sincronizacao`, depois `function-fluxo-sincronizacao.png` (caminho absoluto; comment `Doc: diagrama function-fluxo-sincronizacao`).
   - `confluence_get_attachments`: os dois têm que aparecer. Anote a versão do anexo `function-fluxo-sincronizacao`.
   - Se o upload não aparecer: siga o "Plano B" do drawio.md e avise.

5. Ajuste no XML, só se necessário e só estes três valores na macro `drawio`: `revision` (versão do anexo, se diferente de 1), `diagramWidth` e `height` (largura e altura medidas, divididas por 2 se a exportação tiver saído em escala 2x). Nada mais.

6. Publique: `confluence_update_page` com `page_id: 3518078392`, `title: "Azure Function"`, `content` = conteúdo integral de `azure-function.storage.xml`, `content_format: "storage"`, `is_minor_edit: false`, `version_comment: "Doc: página de ouro (reescrita completa)"`.

7. Verifique: leia a página de novo com `convert_to_markdown: false` e confirme:
   - `grep -o "<ac:structured-macro" <arquivo salvo> | wc -l` = 9
   - a macro `drawio` aponta para `function-fluxo-sincronizacao`.

8. Me entregue: versão antes e depois, resultado do passo 3, lista de anexos e contagem de macros. Para desfazer, o backup do passo 2 é o rollback.
