---
name: publicar-confluence-bradesco
description: 'Mecânica de leitura e escrita no Confluence Data Center do Bradesco pelo MCP mcp-atlassian: formato de armazenamento, macros permitidas, contagem de macros, diagramas draw.io com anexo e macro. Use sempre que for ler, editar, criar ou publicar uma página do Confluence, ou inserir um diagrama.'
user-invocable: false
---

# Publicar no Confluence (Bradesco)

Instância: Confluence Data Center em `confluence.bradesco.com.br:8443`, espaço `TRIBO`. Servidor MCP: `mcp-atlassian`.

## Regra zero: sempre formato de armazenamento

O MCP converte para Markdown por padrão. Markdown destrói macros. Por isso:

- Leitura: `confluence_get_page` com `convert_to_markdown: false` e `include_metadata: true`.
- Escrita: `confluence_update_page`, `confluence_update_page_section` ou `confluence_create_page` sempre com `content_format: "storage"`.
- Conteúdo grande: grave o XHTML num arquivo da pasta `doc-rascunhos` e passe em `content_file` (criação) em vez de colar no parâmetro.
- Nunca envie bloco de código com linguagem `mermaid`. A macro `mermaid` não existe nesta instância e aparece como "Macro desconhecida".

## Arquivos de trabalho de cada página

Na pasta `doc-rascunhos/<componente>/`:

- `<slug>.original.xml`: o storage format lido antes de qualquer mudança. Nunca editado. Serve para contagem e rollback.
- `<slug>.rascunho.xml`: o storage format novo, que vai para o revisor e depois para o Confluence.
- `<nome-diagrama>.drawio`, `<nome-diagrama>.png`: diagramas (seção Diagramas).

## Preservação

- Altere apenas o trecho necessário. Para mudança em uma seção, prefira `confluence_update_page_section` (o `heading_text` tem que bater exatamente com o título).
- Preserve `<ac:structured-macro>`, `<ac:parameter>`, `<ac:rich-text-body>`, `<ac:plain-text-body>`, `<ri:*>`, `<ac:layout>`, âncoras, links e anexos. Nunca converta macro em texto.
- Preserve o `ac:macro-id` das macros existentes.

## Contagem de macros antes de salvar

O terminal é Git Bash. Rode e compare os dois números:

```
grep -o "<ac:structured-macro" "<slug>.original.xml" | wc -l
grep -o "<ac:structured-macro" "<slug>.rascunho.xml" | wc -l
```

Se o número cair sem que a remoção esteja aprovada no plano, não salve: pergunte.

## Macros permitidas

Use apenas as macros de [references/macros.md](references/macros.md). Macro nova na página precisa estar aprovada no plano.

## Diagramas draw.io

Siga [references/drawio.md](references/drawio.md). Resumo: gerar `.drawio` com as skills `draw-io-diagram-generator` e `drawio`, validar, exportar PNG, subir dois anexos e inserir a macro `drawio` com `revision` igual à versão do anexo.

## Depois de salvar

1. Leia a página de novo com `convert_to_markdown: false` e confirme a contagem de macros.
2. `version_comment` sempre no formato `Doc: <resumo da mudança>`.
3. `is_minor_edit: true` para reformatação; `false` para mudança de conteúdo técnico.
