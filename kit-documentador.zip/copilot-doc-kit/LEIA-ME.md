# Kit do Documentador (Tech Writer)

Agente genérico para documentar sistemas e componentes no Confluence do Bradesco. A Molicar, ou qualquer outro sistema, entra pelo escopo de cada rodada.

```
prompts/                         vai para %APPDATA%\Code\User\prompts (harness Local)
  documentador.agent.md          agente que você seleciona no chat
  revisor-doc.agent.md           subagente de revisão (não aparece no menu)
  documentacao.instructions.md   regras de conteúdo (padrão de qualidade)
skills/confluence-bradesco/      vai para ~/.copilot/skills (ler e escrever no Confluence, macros, draw.io)
baixar-skills.sh                 baixa as 17 skills de terceiros
instalar.sh                      instala ou atualiza; nunca sobrescreve o drawio.md confirmado
```

## Instalar ou atualizar

No Git Bash, dentro desta pasta:

1. `bash baixar-skills.sh` (só na primeira vez).
2. `bash instalar.sh`.
3. Reload Window no VS Code.

O `references/drawio.md` não vem no zip: o confirmado na sua máquina é a fonte da verdade. O `instalar.sh` renomeia a skill antiga `publicar-confluence-bradesco` para `confluence-bradesco` levando o arquivo junto.

## Conferir

1. Engrenagem do chat: o Documentador, a instruction e a skill `confluence-bradesco` aparecem; a `publicar-confluence-bradesco` não aparece mais.
2. Abra o `documentador.agent.md` no VS Code e confira se `vscode/askQuestions` não está sublinhado. Se estiver, use o autocompletar dentro de `tools` para achar o nome certo da ferramenta de perguntas na sua versão.

## Primeira rodada

Selecione o Documentador e mande só:

```
Reformatar a página da Azure Function da Molicar pelas regras de legibilidade.
```

Ele pergunta o resto do escopo (espaço, página pai, código, documentação existente) e para no plano. Compare o plano com a página atual antes de aprovar.
