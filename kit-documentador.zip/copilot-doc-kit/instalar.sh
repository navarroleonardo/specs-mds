#!/usr/bin/env bash
# Instala o kit do Documentador no perfil do usuário.
# No Git Bash, dentro da pasta extraída:  bash instalar.sh
set -e
mkdir -p "$HOME/.copilot" "$HOME/doc-rascunhos"
cp -r .copilot/. "$HOME/.copilot/"
echo "Instalado em $HOME/.copilot"
echo "Pasta de rascunhos: $HOME/doc-rascunhos"
echo "Proximo passo: File > Add Folder to Workspace... e adicione $HOME/doc-rascunhos ao navas-workspace."
