# Macros permitidas (Confluence Data Center)

Esta lista é o padrão. Use os formatos abaixo mesmo que páginas existentes do espaço usem outro: elas não são referência de qualidade. Macro fora desta lista exige aprovação no plano.

Única exceção: macros que dependem de configuração da instância (`jira`) precisam de parâmetros que só existem lá; para elas, leia de uma página existente apenas esses parâmetros, nunca o resto do formato.

**Proibida:** `mermaid` (não existe na instância).

## Destaque

`info`, `note`, `warning`, `tip`: resumo, observação, risco operacional, dica.

```xml
<ac:structured-macro ac:name="warning" ac:schema-version="1">
  <ac:parameter ac:name="title">runOnStartup ativo</ac:parameter>
  <ac:rich-text-body><p>O timer também dispara em restart, scale-out e deploy.</p></ac:rich-text-body>
</ac:structured-macro>
```

`panel`: o Resumo rápido no topo da página.

```xml
<ac:structured-macro ac:name="panel" ac:schema-version="1">
  <ac:parameter ac:name="title">Resumo rápido</ac:parameter>
  <ac:rich-text-body><ul><li><strong>O que faz:</strong> ...</li></ul></ac:rich-text-body>
</ac:structured-macro>
```

## Código e artefatos

`code`: SQL, JSON, JavaScript, Java, YAML. Sempre com `language`. Use o valor que já aparece em páginas do espaço; na dúvida, `text`.

```xml
<ac:structured-macro ac:name="code" ac:schema-version="1">
  <ac:parameter ac:name="language">sql</ac:parameter>
  <ac:plain-text-body><![CDATA[SELECT 1;]]></ac:plain-text-body>
</ac:structured-macro>
```

`noformat`: exemplo de arquivo ou texto bruto (CSV, linha de log).

```xml
<ac:structured-macro ac:name="noformat" ac:schema-version="1">
  <ac:plain-text-body><![CDATA[idEstado,nome,siglaEstado]]></ac:plain-text-body>
</ac:structured-macro>
```

`expand`: scripts longos, payloads, detalhes opcionais.

```xml
<ac:structured-macro ac:name="expand" ac:schema-version="1">
  <ac:parameter ac:name="title">Ver script completo</ac:parameter>
  <ac:rich-text-body><p>...</p></ac:rich-text-body>
</ac:structured-macro>
```

## Navegação

`toc` (páginas com 4 ou mais seções):

```xml
<ac:structured-macro ac:name="toc" ac:schema-version="1">
  <ac:parameter ac:name="maxLevel">2</ac:parameter>
</ac:structured-macro>
```

`anchor` e link para a âncora (usado quando um fato é citado em outra seção):

```xml
<ac:structured-macro ac:name="anchor" ac:schema-version="1">
  <ac:parameter ac:name="">retorno-http</ac:parameter>
</ac:structured-macro>

<ac:link ac:anchor="retorno-http"><ac:plain-text-link-body><![CDATA[ver retorno do trigger HTTP]]></ac:plain-text-link-body></ac:link>
```

Link para outra página:

```xml
<ac:link><ri:page ri:content-title="Azure Data Factory" /></ac:link>
```

`children`: índice das páginas filhas.

```xml
<ac:structured-macro ac:name="children" ac:schema-version="2" />
```

## Status e conteúdo canônico

`status`:

```xml
<ac:structured-macro ac:name="status" ac:schema-version="1">
  <ac:parameter ac:name="colour">Green</ac:parameter>
  <ac:parameter ac:name="title">EM PRODUÇÃO</ac:parameter>
</ac:structured-macro>
```

`excerpt` e `excerpt-include`. Atenção: no Data Center nativo, **cada página tem um único `excerpt`**. Por isso o status de todos os componentes fica numa tabela da Visão Geral, e as páginas de componente apenas linkam para ela.

```xml
<ac:structured-macro ac:name="excerpt" ac:schema-version="1">
  <ac:rich-text-body><p>...</p></ac:rich-text-body>
</ac:structured-macro>

<ac:structured-macro ac:name="excerpt-include" ac:schema-version="1">
  <ac:parameter ac:name="nopanel">true</ac:parameter>
  <ac:parameter ac:name=""><ac:link><ri:page ri:content-title="Visão Geral" /></ac:link></ac:parameter>
</ac:structured-macro>
```

## Jira

`jira`: referenciar card ou test execution. Os parâmetros `server` e `serverId` são da instância: copie só esses dois de uma página que já use a macro.

```xml
<ac:structured-macro ac:name="jira" ac:schema-version="1">
  <ac:parameter ac:name="server">(da instância)</ac:parameter>
  <ac:parameter ac:name="serverId">(da instância)</ac:parameter>
  <ac:parameter ac:name="key">PROJ-123</ac:parameter>
</ac:structured-macro>
```

## Diagramas

`drawio`: ver [drawio.md](drawio.md).

`inc-drawio` (Embed draw.io Diagram): contrato ainda não confirmado nesta instância. Não usar até ele ser adicionado aqui.
