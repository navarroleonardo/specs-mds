#!/usr/bin/env bash
# Instala o kit do Documentador (harness Local do VS Code).
# No Git Bash, dentro da pasta extraída:  bash instalar.sh
set -e
prompts="$APPDATA/Code/User/prompts"     # agentes e instructions de usuário do harness Local
skills="$HOME/.copilot/skills"           # skills pessoais
mkdir -p "$prompts" "$skills" "$HOME/doc-rascunhos"
cp prompts/* "$prompts/"
cp -r skills/. "$skills/"
echo "Agentes e instructions: $prompts"
echo "Skills: $skills"
echo "Rascunhos: $HOME/doc-rascunhos (adicione ao navas-workspace)"
