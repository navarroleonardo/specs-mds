#!/usr/bin/env bash
# Instala/atualiza o kit do Documentador (harness Local do VS Code).
# No Git Bash, dentro desta pasta:  bash instalar.sh
# Seguro para rodar de novo: nunca sobrescreve references/drawio.md já existente.
set -e
prompts="$APPDATA/Code/User/prompts"
skills="$HOME/.copilot/skills"
nova="$skills/confluence-bradesco"
antiga="$skills/publicar-confluence-bradesco"
mkdir -p "$prompts" "$skills" "$HOME/doc-rascunhos"

# Migração do nome antigo da skill, preservando o drawio.md confirmado
if [ -d "$antiga" ] && [ ! -d "$nova" ]; then
  mv "$antiga" "$nova"
  echo "Skill renomeada: publicar-confluence-bradesco -> confluence-bradesco"
elif [ -d "$antiga" ]; then
  echo "AVISO: existem as duas pastas ($antiga e $nova). Confira o drawio.md e apague a antiga."
fi

cp prompts/* "$prompts/"
mkdir -p "$nova/references"
cp skills/confluence-bradesco/SKILL.md "$nova/"
cp skills/confluence-bradesco/references/macros.md "$nova/references/"
if [ -f "$nova/references/drawio.md" ]; then
  echo "drawio.md existente preservado."
elif [ -f skills/confluence-bradesco/references/drawio.md ]; then
  cp skills/confluence-bradesco/references/drawio.md "$nova/references/"
else
  echo "AVISO: drawio.md não encontrado em lugar nenhum. Restaure pelo git."
fi

echo "Agentes e instructions: $prompts"
echo "Skill: $nova"
grep -rli "molicar" "$prompts"/documentador.agent.md "$prompts"/revisor-doc.agent.md "$prompts"/documentacao.instructions.md "$nova" 2>/dev/null \
  && echo "AVISO: ainda há menção a Molicar nos arquivos acima." || echo "Sem menção a Molicar."
