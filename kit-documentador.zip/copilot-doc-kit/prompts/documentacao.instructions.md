---
name: 'Documentação técnica'
description: 'Regras de conteúdo para documentar sistemas e componentes no Confluence: fontes, nomenclatura, estrutura das páginas e legibilidade. Use ao criar, revisar ou reformatar documentação técnica.'
---

# Regras de conteúdo da documentação

Este arquivo diz O QUE escrever. O fluxo de trabalho está no agente Documentador. Estas regras são o padrão de qualidade: páginas existentes no Confluence servem como fonte de fatos, nunca como modelo de formato. A mecânica do Confluence (formato de armazenamento, macros, anexos, draw.io) está na skill `confluence-bradesco`.

## 1. Hierarquia de confiança

Quando duas fontes divergirem, a de nível mais alto é a verdade:

1. Código-fonte (código da Function, JSON das pipelines e data flows do ADF, DDL, procedures, functions, scripts de materialized views e refresh, seeders)
2. Especificações OpenSpec e ADRs do repositório (podem estar defasadas)
3. Markdown local
4. Confluence

O código vence, mas divergência nunca é corrigida por conta própria: vira pergunta.

## 2. Formato das perguntas

Agrupe todas as perguntas pendentes numa única mensagem. Uma decisão por pergunta.

```
**P1. <pergunta objetiva>**
Contexto: <1 a 2 linhas, com fonte A vs fonte B>
- A) <opção>
- B) <opção>
- C) <opção>
- D) Outro: descreva
```

## 3. Fonte única da verdade

- Cada informação tem uma página canônica. As demais referenciam por link ou `excerpt-include`.
- O status da demanda e de cada componente vive apenas na Visão Geral.
- Antes de criar página, seção ou ADR, busque no espaço e no repositório se o assunto já existe. Se existir, proponha consolidação.
- ADR substituída não é excluída: recebe status "Substituída por ADR-XXX" e link para a nova.

## 4. Nomenclatura

- Use nomes exatamente como aparecem no código (recursos Azure, containers, tabelas, colunas, views, procedures, pipelines, activities, data flows, endpoints, variáveis de ambiente), em `código inline`.
- Nunca invente apelido, abreviação ou tradução.
- Taxonomia de ambiente: cada recurso Azure tem três nomes, diferenciados pelo trecho `DV` (desenvolvimento), `HO` (homologação) ou `PR` (produção).
  - No glossário: tabela `Recurso (função) | DV | HO | PR`.
  - No texto: nome completo de um ambiente, ou o padrão com `{DV|HO|PR}` no trecho de ambiente. Nunca encurte o resto do nome.
  - Nome de ambiente que não está no código fica `a confirmar` e vira pergunta.

## 5. Tipo de página → skill (arc42 + Diátaxis)

A árvore de páginas existente no Confluence não muda. Classifique cada página do escopo por tipo e use a skill indicada na Fase 1. Se uma página não se encaixar em nenhum tipo, pergunte.

| Tipo de página | Conteúdo | Skill |
|---|---|---|
| Visão geral do sistema ou da demanda | Objetivo, metas de qualidade, status por componente, riscos e débito técnico (seções 1, 11), glossário (seção 12) | `arc42-section-01`, `arc42-section-11`, `arc42-section-12` |
| Contexto (C4 nível 1) | Contexto e escopo (seção 3) | `arc42-section-03` |
| Containers (C4 nível 2) | Blocos de nível 1 (seção 5) | `arc42-section-05` |
| Fluxo ponta a ponta | Visão de execução (seção 6) | `arc42-section-06` |
| Implantação e infraestrutura | Visão de implantação (seção 7) | `arc42-section-07` |
| ADR | Decisões (seção 9), template da seção 6.4 abaixo | `arc42-section-09` |
| Componente (serviço, function, pipeline, base de dados) | Blocos de nível 2, caixa-branca (seção 5) | `arc42-section-05` |
| Operação, runbook, troubleshooting | Guia how-to (fora do arc42) | `documentation-writer` |
| Tutorial, onboarding | Guia de aprendizado (fora do arc42) | `documentation-writer` |

Ajustes obrigatórios ao usar as skills do arc42:
- Profundidade LEAN, a menos que o escopo peça outra.
- Diagramas sempre em draw.io, pela skill `confluence-bradesco`. Ignore a orientação de PlantUML do toolkit.
- Saída na pasta `doc-rascunhos` do workspace, nunca em `docs/` de um repositório.
- Tudo em português.

## 6. Estrutura das páginas

### 6.1 Visão Geral
1. Resumo rápido (seção 7.3)
2. Objetivo e motivação
3. Metas de qualidade (até 3, com número: ex. consulta abaixo de 10 ms)
4. Diagrama de contexto (embed do C4 existente, não recriar)
5. Status por componente (`status` + `excerpt`)
6. Riscos e débito técnico
7. Links para componentes e ADRs
8. Glossário

### 6.2 Página de componente
1. Resumo rápido (seção 7.3), sem seção "Resumo" separada
2. Entradas e saídas (origem, formato, destino)
3. Fluxo passo a passo
4. Configuração por ambiente (tabela DV, HO, PR)
5. Dependências
6. Falhas e reprocessamento
7. Operação e observabilidade (como executar, validar, onde ver logs)
8. Referências de código (caminhos)

### 6.3 Seções extras de base de dados
- Modelo (deixar explícito o relacionamento só lógico)
- Carga em staging (origem, volume, tempo)
- Normalização (procedure, ordem, destino)
- Materialized views (finalidade, ordem de consulta do canal, refresh concorrente)
- Circuit breakers (condição de abertura, efeito)
- Hot swap (sequência e rollback)
- Seeders e tabelas de domínio
- Ordem de execução dos scripts

### 6.4 ADR
```
ADR-NNN: <decisão>
Status: <status> | Data: <AAAA-MM-DD>
Contexto
Decisão
Alternativas consideradas
Consequências
Referências (arquivos de código, ADRs relacionadas)
```

## 7. Legibilidade (obrigatório)

Objetivo: o leitor entende o componente em 1 minuto rolando a página. Tabela em excesso é tão ruim quanto prosa em excesso.

### 7.1 Escolha do formato (use o PRIMEIRO que servir)
1. Exemplo concreto em `code` ou `noformat`: quando o conteúdo é um artefato (arquivo, payload, request, linha de log, comando).
2. Lista simples: enumerações e pares no formato `**Rótulo:** valor`.
3. Lista numerada: passos em sequência.
4. Prosa curta (até 3 frases): o porquê, o contexto, a consequência.
5. Tabela: SOMENTE com 3 ou mais linhas E 3 ou mais colunas, quando o leitor compara valores entre linhas.
6. Macro de destaque (`warning`, `note`, `tip`): risco, comportamento não óbvio.
7. Diagrama draw.io: fluxo com desvio, arquitetura, sequência entre componentes.

### 7.2 Limites duros
- Tabela de 2 colunas é proibida. Vira lista `**Rótulo:** valor`.
- Máximo 1 tabela por seção de nível 2, exceto a tabela DV/HO/PR.
- Nunca duas tabelas seguidas.
- Um fato aparece uma única vez na página. A outra seção aponta com `anchor`.
- Coluna que repete informação de outra tabela ou seção sai.
- Conteúdo de outro componente vale no máximo 1 frase e um link para a página dele.
- Tabela só com itens da mesma natureza.

### 7.3 Resumo rápido
Painel no topo, até 5 itens: o que faz, quando roda, entradas, saídas, onde falha. Cada item traz um fato concreto e não repete a frase de abertura.
- Ruim: `Onde falha: falhas seguem tratamento diferente conforme o trigger.`
- Bom: `Onde falha: se o timer falhar não há alerta; o ADF segue usando o último CSV gravado.`

### 7.4 Horários
- Cron sempre traduzido, em UTC e em Brasília (UTC-3). Ex.: `0 0 10 * * 1` = toda segunda às 10:00 UTC (07:00 em Brasília).
- `runOnStartup: true` exige `warning`: o timer também dispara em restart, scale-out e deploy.

### 7.5 Exemplo de conversão
Ruim (tabela de 2 colunas descrevendo um arquivo):
```
| Elemento    | Contrato                  |
| Delimitador | ,                         |
| Cabeçalho   | idEstado,nome,siglaEstado |
| Lista vazia | Só o cabeçalho            |
```
Bom (exemplo + lista curta):
```
Exemplo de ageo-uf-ref.csv:
[noformat]
idEstado,nome,siglaEstado
<valor>,<valor>,<valor>
[/noformat]
- Delimitador `,`, quebra de linha `\n`, UTF-8.
- Espaços nas extremidades de `nome` e `siglaEstado` são removidos.
- Se a API retornar lista vazia, o arquivo contém só o cabeçalho.
```
Valores de exemplo vêm de teste, fixture ou código. Se não houver, use `<placeholder>`. Nunca invente valores.

### 7.6 Regras gerais
- Segredos: só o nome da referência, nunca o valor.
- Reformatar não autoriza mudar conteúdo técnico. Toda informação continua presente ou vai para a página dona dela, com link.
