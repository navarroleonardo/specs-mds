# Instala o kit do Documentador no perfil do usuário.
# Rode no PowerShell, dentro da pasta onde o zip foi extraído:  .\instalar.ps1

$ErrorActionPreference = "Stop"
$destino = Join-Path $env:USERPROFILE ".copilot"
$rascunhos = Join-Path $env:USERPROFILE "doc-rascunhos"

# Copia agents, instructions e skills sem apagar o que já existe em ~/.copilot
robocopy ".\.copilot" $destino /E /NFL /NDL /NJH /NJS | Out-Null
if ($LASTEXITCODE -ge 8) { throw "Falha no robocopy (codigo $LASTEXITCODE)" }

# Pasta de trabalho dos rascunhos
New-Item -ItemType Directory -Force $rascunhos | Out-Null

Write-Host "Instalado em $destino"
Write-Host "Pasta de rascunhos: $rascunhos"
Write-Host "Proximo passo: no VS Code, File > Add Folder to Workspace... e adicione $rascunhos ao navas-workspace."
