# Kit do Documentador (Molicar)

Conteúdo:

```
.copilot/
  agents/documentador.agent.md       agente que você seleciona no chat
  agents/revisor-doc.agent.md        subagente de revisão (não aparece no menu)
  instructions/documentacao.instructions.md   regras de conteúdo
  skills/publicar-confluence-bradesco/        mecânica do Confluence, macros e draw.io
instalar.ps1
```

## Instalar

1. Instale antes as skills de terceiros (guia de setup, seções 4 e 5): `documentation-writer`, `drawio`, `draw-io-diagram-generator` e as 14 do arc42-toolkit.
2. Extraia este zip e rode `.\instalar.ps1` no PowerShell.
3. Adicione `%USERPROFILE%\doc-rascunhos` ao `navas-workspace` (File > Add Folder to Workspace).
4. Recarregue o VS Code (Developer: Reload Window).

## Conferir

1. Chat > botão direito > Diagnostics: os dois agentes, a instruction e a skill carregados, sem erro.
2. Selecione o agente **Documentador** e clique no ícone de ferramentas: as tools do `mcp-atlassian` listadas no arquivo têm que aparecer marcadas. Ferramenta com nome errado é ignorada sem erro. Se alguma embutida (`read`, `search`, `edit`, `execute`, `agent`, `todo`) faltar, abra o `.agent.md` no VS Code: nome inválido aparece sublinhado e o autocompletar dentro de `tools` sugere o nome certo da sua versão.

## Primeira rodada sugerida

Passo 0 do draw.io (uma vez): peça ao Documentador para executar o "Passo 0" de `references/drawio.md` na página do C4 e atualizar o campo "Resultado confirmado".

Depois:

```
ESCOPO
- Componente: fini-fun-syncageo (Azure Function)
- Páginas: Azure Function (TRIBO)
- Arquivos: somente leitura no repositório da Function
Objetivo: reformatar a página pelas regras de legibilidade, remover a macro mermaid,
mover "Consumo pelo ADF" para 1 frase + link, e propor o diagrama do fluxo em draw.io.
```

Pare no plano e compare com a página atual antes de aprovar.
