# Diagramas draw.io no Confluence

## Contrato da macro (lido do espaço TRIBO em 2026-10-02)

Macro criada à mão na página do C4, formato de armazenamento:

```xml
<ac:structured-macro ac:macro-id="89dd7e6c-6d29-4174-afc4-3f6b94297c82" ac:name="drawio" ac:schema-version="1">
  <ac:parameter ac:name="border">true</ac:parameter>
  <ac:parameter ac:name="diagramName">c4</ac:parameter>
  <ac:parameter ac:name="simpleViewer">false</ac:parameter>
  <ac:parameter ac:name="width"></ac:parameter>
  <ac:parameter ac:name="links">auto</ac:parameter>
  <ac:parameter ac:name="tbstyle">top</ac:parameter>
  <ac:parameter ac:name="lbox">true</ac:parameter>
  <ac:parameter ac:name="diagramWidth">809</ac:parameter>
  <ac:parameter ac:name="height">1139</ac:parameter>
  <ac:parameter ac:name="revision">1</ac:parameter>
  <ac:parameter ac:name=""></ac:parameter>
</ac:structured-macro>
```

O desenho não fica no corpo da página. Fica em anexos da página, ligados pelo `diagramName`. O `revision` aponta a versão do anexo que a macro mostra.

## Passo 0: confirmar os nomes dos anexos (uma vez só)

Antes do primeiro diagrama, chame `confluence_get_attachments` na página que tem a macro `c4` e confira:

- Esperado: um anexo `c4` (o XML do diagrama, sem extensão) e um anexo `c4.png` (a prévia).
- Se os nomes forem outros, pare, mostre a lista ao usuário e peça para atualizar esta seção. Não deduza.

Resultado confirmado: `a confirmar`

## Criar um diagrama novo

1. **Nome:** kebab-case, com o componente na frente. Ex.: `function-fluxo-sincronizacao`, `adf-pipeline-carga`.
2. **Gerar:** use a skill `draw-io-diagram-generator` (template do tipo certo, paleta, no máximo 40 elementos) e grave `doc-rascunhos/<componente>/<nome>.drawio` sem compressão.
3. **Validar:** `python <pasta da skill draw-io-diagram-generator>/scripts/validate-drawio.py <nome>.drawio`. Corrija até passar.
4. **Exportar a prévia:** `& "C:\Program Files\draw.io\draw.io.exe" -x -f png -e -b 10 -o <nome>.png <nome>.drawio`
5. **Medir a prévia:** `python -c "import struct,sys;d=open(sys.argv[1],'rb').read(24);print(*struct.unpack('>II',d[16:24]))" <nome>.png` devolve largura e altura em px.
6. **Preparar o anexo XML:** `Copy-Item <nome>.drawio <nome>` (cópia sem extensão, porque o nome do arquivo vira o nome do anexo).
7. **Subir os dois anexos:** `confluence_upload_attachment` com `content_id` da página e `file_path` absoluto, primeiro `<nome>`, depois `<nome>.png`. Use `comment: "Doc: diagrama <nome>"`.
8. **Conferir o upload:** `confluence_get_attachments` na página. Os dois anexos têm que aparecer. Há um bug conhecido em que o MCP diz "sucesso" e o anexo não sobe no Data Center. Se não aparecerem, vá para "Plano B".
9. **Inserir a macro:** copie o contrato acima, sem `ac:macro-id` (o Confluence gera), com `diagramName` = `<nome>`, `diagramWidth` = largura, `height` = altura, `revision` = versão do anexo `<nome>` (1 para anexo novo). Mantenha o parâmetro vazio do final.
10. **Verificar:** releia a página e confirme que a macro está lá e a contagem de macros subiu exatamente 1.

## Atualizar um diagrama existente

1. Baixe o XML atual com `confluence_download_attachment` (anexo `<nome>`) para `doc-rascunhos/<componente>/<nome>.drawio`. Edite a partir dele, nunca do zero.
2. Repita os passos 3 a 8 de "Criar". O upload com o mesmo nome cria uma nova versão do anexo.
3. Na macro existente, mude só `revision` (nova versão do anexo), `diagramWidth` e `height`. Preserve o `ac:macro-id`.

## Plano B (upload falhou)

Pare e entregue ao usuário:

- O caminho do `<nome>.drawio` gerado.
- Instrução: editar a página, inserir a macro **draw.io Diagram**, escolher o diagrama em branco, arrastar o arquivo para a tela (ou Extras > Editar diagrama e colar o XML), salvar com o nome `<nome>` e publicar.

Registre "diagrama inserido manualmente" no changelog.
