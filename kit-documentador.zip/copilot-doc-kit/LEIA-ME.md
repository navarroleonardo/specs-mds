# Kit do Documentador (Molicar)

Conteúdo:

```
prompts/                       vai para %APPDATA%\Code\User\prompts (harness Local)
  documentador.agent.md        agente que você seleciona no chat
  revisor-doc.agent.md         subagente de revisão (não aparece no menu)
  documentacao.instructions.md regras de conteúdo
skills/                        vai para ~/.copilot/skills
  publicar-confluence-bradesco/  mecânica do Confluence, macros e draw.io
baixar-skills.sh               baixa as skills de terceiros
instalar.sh
```

## Instalar

1. Instale antes as skills de terceiros: `bash baixar-skills.sh` (17 skills, 30 arquivos).
2. Extraia este zip e, no Git Bash, dentro da pasta extraída: `bash instalar.sh`.
3. Adicione `~/doc-rascunhos` ao `navas-workspace` (File > Add Folder to Workspace).
4. Recarregue o VS Code (Developer: Reload Window).

## Conferir

1. Chat > botão direito > Diagnostics: os dois agentes, a instruction e a skill carregados, sem erro.
2. Selecione o agente **Documentador** e clique no ícone de ferramentas: as tools do `mcp-atlassian` listadas no arquivo têm que aparecer marcadas. Ferramenta com nome errado é ignorada sem erro. Se alguma embutida (`read`, `search`, `edit`, `execute`, `agent`, `todo`) faltar, abra o `.agent.md` no VS Code: nome inválido aparece sublinhado e o autocompletar dentro de `tools` sugere o nome certo da sua versão.

## Primeira rodada sugerida

Passo 0 do draw.io (uma vez): peça ao Documentador para executar o "Passo 0" de `references/drawio.md` na página do C4 e atualizar o campo "Resultado confirmado".

Depois:

```
ESCOPO
- Componente: fini-fun-syncageo (Azure Function)
- Páginas: Azure Function (TRIBO)
- Arquivos: somente leitura no repositório da Function
Objetivo: reformatar a página pelas regras de legibilidade, remover a macro mermaid,
mover "Consumo pelo ADF" para 1 frase + link, e propor o diagrama do fluxo em draw.io.
```

Pare no plano e compare com a página atual antes de aprovar.
